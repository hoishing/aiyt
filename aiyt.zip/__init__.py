metadata = {
    "name": "aiyt",
    "version": "0.4.7",
    "description": "Transcribe, Chat and Summarize Youtube Video with AI",
}
